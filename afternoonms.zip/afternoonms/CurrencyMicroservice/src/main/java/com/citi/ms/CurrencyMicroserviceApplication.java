package com.citi.ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyMicroserviceApplication.class, args);
	}

}
